export default [
  {
    ignores: ['dist/**/*']
  }
];
