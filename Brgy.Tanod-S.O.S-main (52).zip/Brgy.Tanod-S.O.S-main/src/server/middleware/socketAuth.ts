import { Socket } from "socket.io";
import jwt from "jsonwebtoken";
import { config } from "../config/index";
import { AuthenticatedSocket, UserPayload } from "../types";
import { admin } from "../db/index";

export const socketAuthMiddleware = async (socket: Socket, next: (err?: Error) => void) => {
  const cookieHeader = socket.handshake.headers.cookie || '';
  
  const cookies: Record<string, string> = {};
  if (cookieHeader) {
    cookieHeader.split(';').forEach(c => {
      const [key, val] = c.trim().split('=');
      cookies[key] = val;
    });
  }
  const cookieToken = cookies['token'];

  const authData = socket.handshake.auth || {};
  let token = 
    authData.token || 
    cookieToken ||
    socket.handshake.headers.authorization?.split(" ")[1];

  if (token === 'cookie-auth' || token === 'null' || token === 'undefined') {
    token = cookieToken;
  }

  if (!token) {
    const authKeys = Object.keys(authData).join(', ');
    const handshakeHeaders = JSON.stringify(socket.handshake.headers);
    console.warn(`[SocketAuth] Authentication FAILED for socket ${socket.id}: No valid token found. Handshake auth keys: [${authKeys}]. Handshake path: ${socket.handshake.query.path}. Headers: ${handshakeHeaders}`);
    return next(new Error("Authentication required"));
  }

  try {
    let decodedUser: any = null;
    
    // 1. Try Local JWT first (standard for our signed cookies/tokens)
    try {
      const decodedLocal = jwt.verify(token, config.jwtSecret) as any;
      decodedUser = {
        id: decodedLocal.id,
        role: decodedLocal.role,
        email: decodedLocal.email,
        name: decodedLocal.name || decodedLocal.email || 'Local User',
        barangayId: decodedLocal.barangayId
      };
    } catch (jwtErr: any) {
      // 2. Fallback to Firebase verifyIdToken if local fails
      // Special case: if jwt.verify throws "invalid algorithm", it's almost certainly an RS256 token (Firebase)
      if (admin && admin.apps && admin.apps.length > 0) {
        try {
          const decodedToken = await admin.auth().verifyIdToken(token);
          decodedUser = {
            id: decodedToken.uid,
            role: decodedToken.role || 'resident', // defaults to resident if custom claim missing
            email: decodedToken.email,
            name: decodedToken.name || decodedToken.email || 'Firebase User'
          };
        } catch (fbErr: any) {
          console.warn(`[SocketAuth] Both auth methods failed. JWT: ${jwtErr.message}, Firebase: ${fbErr.message}`);
          
          // Handle AI Studio audience mismatch
          if (fbErr.message.includes('aud')) {
            try {
              const decodedToken = jwt.decode(token) as any;
              const isGenLang = decodedToken?.aud?.startsWith('gen-lang-client');
              const isMasterEmail = decodedToken?.email === 'rubenlleg12@gmail.com';
              
              if (isGenLang && isMasterEmail) {
                console.log(`[SocketAuth] Trusting gen-lang-client token for master: ${decodedToken.email}`);
                decodedUser = {
                  id: decodedToken.uid || decodedToken.sub, // sub is often the uid in Google tokens
                  role: 'admin', // Master email gets admin
                  email: decodedToken.email,
                  name: decodedToken.name || decodedToken.email || 'Master User'
                };
              } else {
                throw new Error("Invalid token audience");
              }
            } catch (decodeErr) {
              throw new Error("Invalid token");
            }
          } else {
            throw new Error("Invalid token");
          }
        }
      } else {
        // No Firebase admin, and local JWT failed
        throw jwtErr;
      }
    }
    
    // Set user data to socket
    (socket as AuthenticatedSocket).data = {
      user: {
        id: decodedUser.id,
        role: (decodedUser.role || "CITIZEN").toUpperCase(),
        barangayId: decodedUser.barangayId || "default",
        name: decodedUser.name,
        phone: decodedUser.phone
      }
    };

    console.log(`[SocketAuth] Authenticated user ${decodedUser.id} (${decodedUser.role}) for socket ${socket.id}`);
    next();
  } catch (err: any) {
    console.warn(`[SocketAuth] Authentication FAILED for ${socket.id}: ${err.message}`);
    next(new Error("Authentication error"));
  }
};
